﻿namespace OnlineExaminationApps.Models
{
    public class Message
    {
        public string Title { get; set; }
        public string Messages { get; set; }
        public string CssClassName { get; set; }
    }
}
