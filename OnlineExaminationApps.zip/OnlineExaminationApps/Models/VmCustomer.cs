﻿
namespace OnlineExaminationApps.Models
{
    public class VmCustomer
    {
        public int CustId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
    }
}
